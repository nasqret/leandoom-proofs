import AllForks
open HangarFork ForkData HangarExperiment
example : (evaluate group tape.toArray learned.toArray).bind (fun a => a[0]?.map Outcome.hitTick) = some 924 := by
  rw [allForkOutcomes]
  native_decide
